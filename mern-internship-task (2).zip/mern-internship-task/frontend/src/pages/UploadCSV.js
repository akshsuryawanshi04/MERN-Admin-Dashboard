import React, { useState } from "react";
import axios from "axios";

const UploadCSV = () => {
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [distributedLists, setDistributedLists] = useState([]);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      setError("Please select a file");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    try {
      console.log("Sending request to backend..."); // Log before sending the request
      const response = await axios.post("http://localhost:5000/api/list/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      console.log("Response from backend:", response.data); // Log the response

      if (response.data.distributedLists) {
        setDistributedLists(response.data.distributedLists);
        setMessage(response.data.message);
        setError(""); // Clear any previous errors
      } else {
        setError("No data found in the response");
        setMessage(""); // Clear any previous messages
      }
    } catch (err) {
      setError("Error uploading file");
      setMessage(""); // Clear any previous messages
      console.error("Error uploading file:", err);

      // Log the full error response from the backend (if available)
      if (err.response) {
        console.error("Backend error response:", err.response.data);
      }
    }
  };

  return (
    <div className="upload-csv-container">
      <h2>Upload CSV</h2>
      {message && <p className="success">{message}</p>}
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Select CSV File:</label>
          <input type="file" accept=".csv" onChange={handleFileChange} required />
        </div>
        <button type="submit">Upload</button>
      </form>

      {distributedLists && distributedLists.length > 0 ? (
        <div className="distributed-lists">
          <h3>Distributed Lists</h3>
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Phone</th>
                <th>Notes</th>
                <th>Agent ID</th>
              </tr>
            </thead>
            <tbody>
              {distributedLists.map((list, index) => (
                <tr key={index}>
                  <td>{list.firstName}</td>
                  <td>{list.phone}</td>
                  <td>{list.notes}</td>
                  <td>{list.agentId}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p>No lists distributed yet.</p>
      )}
    </div>
  );
};

export default UploadCSV;