import React, { useState } from "react";
import axios from "axios";

const AddAgent = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [mobile, setMobile] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post("http://localhost:5000/api/agent/add", {
        name,
        email,
        mobile,
        password,
      });

      setMessage(response.data.message);
      setError(""); // Clear any previous errors
      console.log("Agent added successfully:", response.data);
    } catch (err) {
      setError("Error adding agent");
      setMessage(""); // Clear any previous messages
      console.error("Error adding agent:", err);

      // Log the full error response from the backend (if available)
      if (err.response) {
        console.error("Backend error response:", err.response.data);
      }
    }
  };

  return (
    <div className="add-agent-container">
      <h2>Add Agent</h2>
      {message && <p className="success">{message}</p>}
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Mobile:</label>
          <input
            type="text"
            value={mobile}
            onChange={(e) => setMobile(e.target.value)}
            required
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Add Agent</button>
      </form>
    </div>
  );
};

export default AddAgent;