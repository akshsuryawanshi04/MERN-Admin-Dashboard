// frontend/src/pages/Dashboard.js
import React from "react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <h2>Dashboard</h2>
      <nav>
        <ul>
          <li>
            <Link to="/add-agent">Add Agent</Link>
          </li>
          <li>
            <Link to="/upload-csv">Upload CSV</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Dashboard;