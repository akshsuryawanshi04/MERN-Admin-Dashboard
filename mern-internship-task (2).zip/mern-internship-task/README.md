# MERN Internship Task

This is a MERN stack application with the following features:
1. **Admin User Login**:
   - Authenticate users using JWT (JSON Web Tokens).
   - Redirect to the dashboard on successful login.
2. **Agent Creation & Management**:
   - Add agents with details like name, email, mobile, and password.
   - Store agent data in MongoDB.
3. **Uploading and Distributing Lists**:
   - Upload a CSV file containing lists (firstName, phone, notes).
   - Distribute the lists equally among agents.
   - Display the distributed lists in a table.

## Demo Video
[Watch the video demonstration here](#)  
(https://drive.google.com/file/d/1XAKzfoCd7yf_G0i7FL4h-miD4y8j2Mtg/view?usp=sharing)

---

## Setup Instructions

### Prerequisites
1. **Node.js**: Install Node.js from [here](https://nodejs.org/).
2. **MongoDB**: Install MongoDB from [here](https://www.mongodb.com/try/download/community).
3. **Git**: Install Git from [here](https://git-scm.com/).

### Backend Setup
1. Navigate to the `backend` folder:
   cd backend

2. Install dependencies:
   npm install

3. Create a .env file in the backend folder and add the following:

   MONGO_URI=mongodb://localhost:27017/mern_internship
   JWT_SECRET=your_jwt_secret_key
   PORT=5000
   Replace your_jwt_secret_key with a secure secret key for JWT.

4. Start the backend server:
   node server.js
   
   You should see the following logs:

   Server running on port 5000
   MongoDB Connected
   Frontend Setup
   
5. Navigate to the frontend folder:
   cd frontend

6. Install dependencies:
   npm install

7. Start the frontend development server:
   npm start

This will automatically open your browser at http://localhost:3000. If it doesn’t, manually open your browser and go to http://localhost:3000.

___

## 🔗 API Endpoints Overview

### **🔑 Authentication**
- `POST /api/auth/login` → Login as an Admin  
- `POST /api/auth/register` → Register a new Admin  

### **👥 Agent Management**
- `POST /api/agent/create` → Create a new agent  
- `GET /api/agent/all` → Fetch all agents  

### **📂 Upload & List Management**
- `POST /api/list/upload` → Upload a CSV file  
- `GET /api/list` → Retrieve distributed lists  

---

## 📝 How to Upload a CSV File?
1. Open **Postman** or any API testing tool.
2. **Method:** `POST`
3. **URL:** `http://localhost:5000/api/list/upload`
4. **Headers:**
   - Key: `Authorization`
   - Value: `Bearer <your_jwt_token>`  
     _(Replace `<your_jwt_token>` with the actual token from login.)_
5. **Body (form-data):**
   - Key: `file`
   - Type: `File`
   - Upload a CSV file with the format:

     firstName,phone,notes
     John,1234567890,Test note 1
     Jane,0987654321,Test note 2
     
6. Click **Send** and verify the response.

---

## 📹 Application Demo Video
Watch the demo video here: [Click to watch](https://drive.google.com/file/d/1XAKzfoCd7yf_G0i7FL4h-miD4y8j2Mtg/view?usp=sharing)

---

## 🚀 Running the Full Application
1. **Start Backend in Terminal 1:**
   cd backend
   node server.js
  
2. **Start Frontend in Terminal 2:**
   cd frontend
   npm start
   
Now open **`http://localhost:3000/`** in the browser.



## 💡 Troubleshooting
- **MongoDB Connection Error?**  
  - Ensure MongoDB is running locally or your connection string is correct in `.env`.
- **Port Already in Use?**  
  - Change the `PORT` in `backend/server.js` or terminate the process using:

    npx kill-port 5000
   
- **Frontend Not Loading?**  
  - Restart the frontend:  

    cd frontend
    npm start

---

## 🤝 Contributing
Feel free to contribute by opening an issue or pull request!

---

### 🔗 **Author**
👤 **Akash Suryawanshi**  
📧 Email: akashsuryawanshi1344@gmail.com  
🔗 GitHub: (https://github.com/akashsuryawanshi04)  
🔗 LinkedIn: (https://linkedin.com/in/akashsuryawanshi04)
```
