const multer = require("multer");
const csv = require("csv-parser");
const fs = require("fs");
const List = require("../models/List");
const Agent = require("../models/Agent");

// Configure Multer for file upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage }).single("file");

// Upload CSV and Distribute Lists
const uploadCSV = async (req, res) => {
  console.log("Request received for /api/list/upload"); // Log when the request is received
  upload(req, res, async (err) => {
    if (err) {
      console.error("File upload error:", err);
      return res.status(400).json({ message: "File upload failed" });
    }

    if (!req.file) {
      console.error("No file uploaded");
      return res.status(400).json({ message: "No file uploaded" });
    }

    console.log("File uploaded successfully:", req.file.filename);
    console.log("File path:", req.file.path);

    // Read CSV file
    const results = [];
    console.log("Starting to read CSV file...");
    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on("data", (data) => {
        console.log("Row from CSV:", data); // Log each row of the CSV file
        results.push(data);
      })
      .on("end", async () => {
        console.log("Finished reading CSV file. Total rows:", results.length);

        try {
          // Validate CSV data
          if (!results.every((item) => item.firstName && item.phone)) {
            console.error("Invalid CSV format:", results);
            return res.status(400).json({ message: "Invalid CSV format" });
          }

          console.log("CSV data is valid:", results);

          // Get all agents
          const agents = await Agent.find();
          console.log("Agents found:", agents);

          if (agents.length === 0) {
            console.error("No agents found");
            return res.status(400).json({ message: "No agents found" });
          }

          // Distribute lists among agents
          const distributedLists = [];
          const itemsPerAgent = Math.ceil(results.length / agents.length);

          for (let i = 0; i < results.length; i++) {
            const agentIndex = i % agents.length;
            const list = new List({
              firstName: results[i].firstName,
              phone: results[i].phone,
              notes: results[i].notes,
              agentId: agents[agentIndex]._id,
            });
            await list.save();
            console.log("List saved:", list);
            distributedLists.push(list);
          }

          console.log("Final distributed lists:", distributedLists);
          res.status(200).json({ message: "Lists distributed successfully", distributedLists });
        } catch (err) {
          console.error("Server error:", err);
          res.status(500).json({ message: "Server error" });
        }
      })
      .on("error", (error) => {
        console.error("Error reading CSV file:", error);
        res.status(500).json({ message: "Error reading CSV file" });
      });
  });
};

module.exports = { uploadCSV };