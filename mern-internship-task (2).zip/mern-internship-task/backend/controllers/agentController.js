const Agent = require("../models/Agent");
const bcrypt = require("bcryptjs");

// Add Agent
const addAgent = async (req, res) => {
  const { name, email, mobile, password } = req.body;

  try {
    // Check if agent already exists
    const existingAgent = await Agent.findOne({ email });
    if (existingAgent) {
      return res.status(400).json({ message: "Agent already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create new agent
    const newAgent = new Agent({
      name,
      email,
      mobile,
      password: hashedPassword,
    });

    await newAgent.save();
    res.status(201).json({ message: "Agent created successfully" });
  } catch (err) {
    console.error("Error adding agent:", err);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = { addAgent };