// backend/routes/agentRoutes.js
const express = require("express");
const { addAgent } = require("../controllers/agentController");

const router = express.Router();

// Add Agent Route
router.post("/add", addAgent);

module.exports = router;