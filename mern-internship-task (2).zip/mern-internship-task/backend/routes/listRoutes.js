// backend/routes/listRoutes.js
const express = require("express");
const { uploadCSV } = require("../controllers/listController");

const router = express.Router();

// Upload CSV Route
router.post("/upload", uploadCSV);

module.exports = router;